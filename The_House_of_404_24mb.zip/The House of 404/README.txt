THE LOOP - FIXED PROTOTYPE

Isi:
- game.html
- style.css
- js/game.js
- Models/GLB format/  <- diambil dari ZIP Kenney City Kit Suburban yang kamu upload
- License.txt

PENTING:
1. Semua rumah/perumahan memakai format GLB.
2. Taruh rumah furnished kamu sebagai:
   Models/low_poly_house_interior.glb
3. Jika file furnished house tidak ada, game otomatis memakai building-type-u.glb sebagai fallback supaya tidak blank.
4. HTML memakai:
   <script type="module" src="js/game.js"></script>
5. Jalankan lewat Acode Preview / local server yang bisa membaca file module.

Alur yang sudah dibuat:
- pilih Easy/Medium
- cutscene teks pembuka
- berjalan normal
- dua penculik muncul secara naratif/non-grafis
- blackout
- bangun di rumah
- cari senter
- cari kunci rumah
- cari kunci ruangan
- loop habis -> loop berikutnya
- barang + ingatan tetap
- layout perumahan fixed, tidak random

Catatan:
AI tidak bisa menebak nama/path asset furnished house yang tidak ikut di-upload pada pesan ini. Jadi file tersebut dibuat sebagai optional asset dengan nama yang jelas.


RUMAH + ATAP BARU:
- Models/house_interior.glb = rumah furnished baru
- Models/roof_1_bake.glb = atap
- game.js otomatis mengukur bounding box rumah dan membentangkan/menempatkan atap di atasnya.
- File GLB TIDAK perlu di-extract. Taruh sebagai satu file .glb.
